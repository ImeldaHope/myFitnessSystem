
public class Login {
    String username;
    String password;
    
    public Login(){
        
    }
    public String getusername() {
        return username;
    }

    public void setusername(String newusername) {
        this.username = newusername;
    }

    public String getpassword() {
        return password;
    }

    public void setpassword(String newpassword) {
        this.password= newpassword;
    }
}
