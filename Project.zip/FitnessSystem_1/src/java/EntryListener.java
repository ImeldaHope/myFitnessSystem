import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ValueChangeEvent;
import javax.faces.event.ValueChangeListener;
 
public class EntryListener implements ValueChangeListener{

	@Override
	public void processValueChange(ValueChangeEvent event)
			throws AbortProcessingException {
		
		//access country bean directly
		Administrator myadmin = (Administrator) FacesContext.getCurrentInstance().
			getExternalContext().getSessionMap().get("AdministratorObj");
                String x = event.getNewValue().toString();
		myadmin.setUsername(x);
                
		
	}
	
	
}
