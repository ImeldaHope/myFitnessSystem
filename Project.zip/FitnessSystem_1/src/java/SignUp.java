import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name="UserObj")
@RequestScoped

public class SignUp {
    String username;
    String password;
    String emailAddress;
    String contactDetails;
    String gender;
    String location;
    int paymentDetails;
    
    DBconnect db= new DBconnect();
    Connection myCon=db.myConnect();
    HasherSha1 jk= new HasherSha1();
    
    public SignUp(){}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(String contactDetails) {
        this.contactDetails = contactDetails;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getPaymentDetails() {
        return paymentDetails;
    }

    public void setPaymentDetails(int paymentDetails) {
        this.paymentDetails = paymentDetails;
    }
    
    public void clear(){
        setUsername(null);
        setPassword(null);
        setEmailAddress(null);
        setContactDetails(null);
        setGender(null);
        setLocation(null);
        setPaymentDetails(0);
    }
    public String login() throws SQLException{
         

    Statement statement = myCon.createStatement();
    
    String SQL = "SELECT username, password FROM user WHERE username = '" + getUsername()
            + "' AND password = '" + jk.encryptPassword(getPassword()) + "';";

    ResultSet resultSet = statement.executeQuery(SQL);
    while (resultSet.next()) {
        if (getUsername().equals(resultSet.getString("username")) && jk.encryptPassword(getPassword()).equals(resultSet.getString("password"))) {
            return "home";
        } 
    }
    return "SignIn";
    }
    public void saveUser() throws SQLException{
        Statement s=null;
        if(myCon!=null){
            System.out.println(myCon);
            s=myCon.createStatement();
            
            String sql="INSERT INTO user"
                    +"(userName,password,emailAddress,contactDetails,gender,location,paymentDetails)"
                    +" VALUES ('"+getUsername()+"','"+jk.encryptPassword(getPassword())+ "','"+getEmailAddress()+"','"+getContactDetails()+"','"+getGender()+"','"+getLocation()+"','"+getPaymentDetails()+"')";
                                s.execute(sql);
                                 clear();
        }
    }
}
