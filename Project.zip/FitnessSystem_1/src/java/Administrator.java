import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ValueChangeEvent;
 
@ManagedBean(name="AdminObj")
@SessionScoped
public final class Administrator implements Serializable{
    
    DBconnect db = new DBconnect();//db instance
    Connection myCon = db.myConnect(); //db connection instance
    
    String username;
    String password;
    String emailAddress;
    String contactDetails;
    String gender;
    String location;
    int paymentDetails;
    int id;

    
    
	
	private static final long serialVersionUID = 1L;
	
	public static Map<String,String> user_details;
        
        
	
	private String user; //default value 
	
	

	public void userChanged(ValueChangeEvent e){
		//assign new value to localeCode
		user= e.getNewValue().toString();
		
	}

	public Map<String,String> getUserInMap() {
            get_user_list();
		return this.user_details;
               
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
         String[] token = user.split(";");
        this.username = token[1];
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
         String[] token = user.split(";");
        this.gender = token[3];
    }

    public String getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(String contactdetails) {
         String[] token = user.split(";");
        this.contactDetails = token[4];
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
         String[] token = user.split(";");
        this.emailAddress = token[5];
    }
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
         String[] token = user.split(";");
        this.location = token[7];
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        String[] token = user.split(";");
        this.id = Integer.valueOf(token[0]);
    }
    
    
        
        
        
        
        public void get_user_list(){
 	try {
 	 	Connection connection=null;
 	 	connection=myCon;
                user_details = new LinkedHashMap<>();
 	 	Statement ps=connection.createStatement();
                
 	 	String sql="select distinct * from user order by fname asc";
                
 	 	ResultSet rs=ps.executeQuery(sql);
 	 	while(rs.next()){
              
		
		user_details.put(rs.getString("username"), (rs.getString("id")
                        +";"+rs.getString("username")+";"+rs.getString("gender")
                        +";"+rs.getString("phone")
                        +";"+rs.getString("email")
                        +";"+rs.getString("location"))); //label, value
		
	}
                
 	} catch (Exception e) {
 	 	 System.out.println(e);
 	}
 	
 	}
        public String Edit(){
            return "Administrator";
        }
        public String Delete(){
            return "Administrator";
        }

}
