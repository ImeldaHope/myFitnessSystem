
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DBconnect {
    public DBconnect(){
        
    }
    public Connection myConnect(){
    Connection connect = null;
    try
    {
        Class.forName("com.mysql.jdbc.Driver");
        connect= DriverManager.getConnection(""+"jdbc:mysql://localhost/FitnessSystem"+"?user=root&password");
}
    catch (ClassNotFoundException | SQLException e){
            System.out.println("Cannot connect to Fitness DB"+e.getMessage());
}
    return connect;
}
public static void main(String []args){
    DBconnect mytest= new DBconnect();
    mytest.myConnect();
}
}